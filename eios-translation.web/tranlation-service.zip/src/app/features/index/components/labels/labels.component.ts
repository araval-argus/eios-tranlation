import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { LabelGroupService } from 'src/app/services/label-group.service';
import { LabelService } from 'src/app/services/label.service';
import { LanguageService } from 'src/app/services/language.service';
import { LabelAddComponent } from '../label-add/label-add.component';

@Component({
  selector: 'ts-labels',
  templateUrl: './labels.component.html',
  styleUrls: ['./labels.component.css'],
  providers: [DialogService]
})
export class LabelsComponent implements OnInit {

  languages = [];
  groups = [];
  labels = [];
  totalRecords: number;
  loading: boolean;
  selectAll: boolean = false;
  ref: DynamicDialogRef;
  selectedCustomers = [];
  activeGroupId;
  cols = [];

  constructor(
    private languageService: LanguageService,
    private labelGroupService: LabelGroupService,
    private labelService: LabelService,
    public dialogService: DialogService
  ) { }

  ngOnInit(): void {
    this.getLanguages();
    this.getLabelGroups();

  }
  getLanguages() {
    this.languageService.getLanguages().subscribe((response: any) => {
      this.languages = response.Result;
      this.languages.forEach(lang => {
        if (!lang.isDefault) {
          this.cols.push(lang.name)
        }
      })
    });
  }

  getLabelGroups() {
    this.labelGroupService.getParentLabelGroups().subscribe((response: any) => {
      this.groups = response.Result;
      this.activeGroupId = this.groups[0]?.labelGroupId;
      this.loadLabelsByGroup();
    });
  }

  changeGroup(e) {
    const groupId = this.groups[e.index]?.labelGroupId;
    if (groupId) {
      this.activeGroupId = groupId;
      this.loadLabelsByGroup();
    }
  }

  loadLabelsByGroup() {
    this.labelGroupService.getLabelByGroupDetails(this.activeGroupId).subscribe((response: any) => {
      this.labels = response.Result.labels;
      this.labels = this.labels.map(label => {
        let labelTransformed = {};
        label.translatedLabels.forEach(translated => {
          labelTransformed[translated.languageName] = [];
          labelTransformed[translated.languageName]['machineTranslation'] = translated.machineTranslation;
          labelTransformed[translated.languageName]['labelValue'] = translated.labelValue;
        })
        console.log(labelTransformed)
        return { 'labelName': label.labelName, "labelValue": label.labelValue, translations:  labelTransformed }
      })
      console.log(this.labels)
    })
  }


  // loadLabels() {
  //   this.loading = true;
  //   this.labelService.getLabels().subscribe((response: any) => {
  //     this.labels = response.Result;
  //     this.loading = false;
  //   })
  // }

  showAddLabel() {
    this.ref = this.dialogService.open(LabelAddComponent, {
      header: 'Add Label',
      width: '70%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: true,
      
    });
    this.ref.onClose.subscribe((res) => {
      this.loadLabelsByGroup();
    })
  }
}
