export interface LabelGroup {
    groupName: string,
    labelGroupId?: number,
    fK_ParentLableGroupId?: number
}