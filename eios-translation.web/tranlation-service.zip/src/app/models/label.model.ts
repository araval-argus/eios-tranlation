export interface Label {
    resourceId: string,
    fK_LabelGroupId: number,
    labelValue: string
}