export type TOpens = 'right' | 'left';
export type TDrops = 'up' | 'down';
