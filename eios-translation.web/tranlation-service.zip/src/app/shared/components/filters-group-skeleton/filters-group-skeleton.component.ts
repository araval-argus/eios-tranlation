import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'eios-filters-group-skeleton',
  templateUrl: './filters-group-skeleton.component.html',
  styleUrls: ['./filters-group-skeleton.component.css']
})
export class FiltersGroupSkeletonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
