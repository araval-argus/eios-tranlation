export interface QueryExpression {
  operator: string;
  name?: string;
  path?: string;
  metadata?: any;
}
